#!/system/bin/sh
MODDIR=${0%/*}
# soc_model自动检测
soc_model=MT6989
if [ -z "$soc_model" ]; then
    soc_model=$(getprop ro.soc.model)
    [ -z "$soc_model" ] && soc_model=$(getprop ro.board.platform)
    [ -z "$soc_model" ] && soc_model=$(getprop ro.hardware)
fi
source "$MODDIR/vtools/util.sh"
source "$MODDIR/configs/${soc_model}.sh"

policys_path=/sys/devices/system/cpu/cpufreq
mode=$(cat "$MODDIR/mode" 2>/dev/null || echo "none")
[ -z "$mode" ] && mode="none"

# ---------- 温度监控降频(阈值82°C, 回差76°C) ----------
# 修正: 正常时只读温度, 不再每5秒覆写sysfs(那会造成额外唤醒并覆盖set_speed结果)
TEMPPIDFILE="$MODDIR/temp_monitor.pid"
TEMPSTATE="$MODDIR/temp_state"

# ---------- game_monitor 生命周期 (v1.0.49 新增) ----------
# 仅 performance 档下运行: 白名单游戏前台触发 Fast基座+C(rate_limit跟手)+E(taskset绑核)
GAME_MONITOR_PID="$MODDIR/game_monitor.pid"
kill_game_monitor() {
    if [ -f "$GAME_MONITOR_PID" ]; then
        kill $(cat "$GAME_MONITOR_PID") 2>/dev/null
        rm -f "$GAME_MONITOR_PID"
        log "game_monitor: killed old process"
    fi
    pkill -f "game_monitor.sh" 2>/dev/null
    echo "idle" > "$MODDIR/game_state" 2>/dev/null
}
start_game_monitor() {
    # 避免重复启动
    if [ -f "$GAME_MONITOR_PID" ] && kill -0 $(cat "$GAME_MONITOR_PID") 2>/dev/null; then
        log "game_monitor: already running pid=$(cat $GAME_MONITOR_PID)"
        return 0
    fi
    pkill -f "game_monitor.sh" 2>/dev/null
    sh "$MODDIR/game_monitor.sh" &
    echo $! > "$GAME_MONITOR_PID"
    log "game_monitor: started pid=$!"
}

kill_temp_monitor() {
    if [ -f "$TEMPPIDFILE" ]; then
        kill $(cat "$TEMPPIDFILE") 2>/dev/null
        rm -f "$TEMPPIDFILE"
        log "temp_monitor: killed old process"
    fi
}
start_temp_monitor() {
    kill_temp_monitor
    echo "normal" > "$TEMPSTATE"
    local cur_mode=$mode
    (
        while true; do
            temp=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | cut -d' ' -f1)
            curstate=$(cat "$TEMPSTATE" 2>/dev/null)
            [ -n "$temp" ] || { sleep 5; continue; }
            if [ "$temp" -gt 82000 ] && [ "$curstate" = "normal" ]; then
                # 超过82°C: 温和降频(大核1.6G, 中核1.8G), 保留游戏可玩性
                echo 1600000 > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null
                echo 1800000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
                echo "throttled" > "$TEMPSTATE"
                log "temp_monitor: temp=$temp, throttling CPU7=1.6G CPU4=1.8G"
            elif [ "$temp" -le 76000 ] && [ "$curstate" = "throttled" ]; then
                # 降到76°C以下: 实时重读mode文件, 避免切档后cur_mode过期写错档
                cur_mode=$(cat "$MODDIR/mode" 2>/dev/null)
                case "$cur_mode" in
                    powersave|standby) mode=0; set_speed; set_cpu; powersave_func ;;
                    balance)           mode=1; set_speed; set_cpu; balance_func ;;
                    performance)       mode=2; set_speed; set_cpu; performance_func ;;
                    fast|init|pedestal) mode=3; set_speed; set_cpu; fast_func ;;
                    *)                 mode=1; set_speed; set_cpu; balance_func ;;
                esac
                echo "normal" > "$TEMPSTATE"
                log "temp_monitor: temp=$temp, restored mode=$cur_mode"
            fi
            sleep 5
        done
    ) &
    echo $! > "$TEMPPIDFILE"
    log "temp_monitor: started pid=$!, threshold=82C hysteresis=76C"
}

# v1.0.50 fix: 幂等 skip 提前 + 要求守护健在才 skip
# 修复: 原版 kill 在 case 判断前无条件执行, skip 分支会误杀全部守护且不重建
#       -> 系统卡在旧档位、guard_state=stopped、无人守护(2026-09-09 05:34:39 事故现场)
# 现在: mode 相同且 guard 存活才 skip; mode 相同但守护已死时落入下方具体分支完整重建(自愈)
if [ "$1" = "$mode" ] && [ -f "$MODDIR/guard.pid" ] && kill -0 $(cat "$MODDIR/guard.pid" 2>/dev/null) 2>/dev/null; then
    log "power_switch: already in mode '$1', guard alive, skip"
    exit 0
fi

# 切换前先杀旧监控
kill_guard 2>/dev/null
kill_temp_monitor
# v1.0.49: 任何切档先杀 game_monitor, performance 分支再按需启动(防残留/防跨档)
kill_game_monitor 2>/dev/null

case "$1" in
    "balance")
        mode=1
        set_speed
        set_cpu
        balance_func
        start_temp_monitor
        ;;
    "powersave" | "standby")
        mode=0
        set_speed
        set_cpu
        powersave_func
        start_temp_monitor
        ;;
    "performance")
        mode=2
        set_speed
        set_cpu
        performance_func
        start_temp_monitor
        # v1.0.49: 游戏守护随 performance 档启动(白名单游戏前台才激活, 日常零干预)
        start_game_monitor
        ;;
    "init" | "fast" | "pedestal")
        mode=3
        set_speed
        set_cpu
        fast_func
        start_temp_monitor
        ;;
    *)
        log "power_switch: unknown mode '$1'"
        exit 1
        ;;
esac

echo "$1" > "$MODDIR/mode"
log "power_switch: switched to '$1' (mode=$mode)"