#!/system/bin/sh
propPath=$1
version=$(grep "version=" "$propPath" | head -1 | cut -d "=" -f2)
versionCode=$(grep "versionCode=" "$propPath" | head -1 | cut -d "=" -f2)
json=$(
	cat <<EOF
{
    "name": "background performance drain",
    "author": "偷吃性能",
    "version": "$version",
    "versionCode": ${versionCode},
    "features": {
        "strict": false,
        "pedestal": false
    },
    "module": "background_performance_drain",
    "state": "$MODDIR/mode",
    "entry": "/data/powercfg.sh",
    "projectUrl": ""
}
EOF
)