#!/system/bin/sh

# 日志函数
LOG_FILE="/data/local/tmp/background_performance_drain.log"
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE" 2>/dev/null
}

echo_val() {
    # 节点不存在则静默跳过, 避免Permission denied刷屏
    [ -e "$2" ] || return 0
    chmod 666 "$2" 2>/dev/null
    if ! echo "$1" > "$2" 2>/dev/null; then
        log "echo_val FAILED: $2 <- $1"
    fi
}

lock_val() {
    [ -e "$2" ] || return 0
    chmod 666 "$2" 2>/dev/null
    echo "$1" > "$2" 2>/dev/null
    chmod 444 "$2" 2>/dev/null
}

# 调度器可用性检查
set_governor() {
    local policy=$1 gov=$2
    local gov_path="/sys/devices/system/cpu/cpufreq/policy${policy}/scaling_governor"
    local available=$(cat "/sys/devices/system/cpu/cpufreq/policy${policy}/scaling_available_governors" 2>/dev/null)

    case " $available " in
        *" $gov "*)
            echo_val "$gov" "$gov_path"
            return 0
            ;;
        *)
            log "WARNING: governor '$gov' not available on policy$policy, fallback to schedutil"
            case " $available " in
                *" schedutil "*) echo_val "schedutil" "$gov_path" ;;
                *" interactive "*) echo_val "interactive" "$gov_path" ;;
                *) echo_val "ondemand" "$gov_path" 2>/dev/null ;;
            esac
            return 1
            ;;
    esac
}

parse_config() {
    for tmp in "$@"
    do
        eval "$tmp"
        if [ "$path" = "scaling_min_freq" ] || [ "$path" = "scaling_max_freq" ]; then
            echo_val "${freq[$mode]}" "$policys_path/policy${policy_num[$counter]}/$path"
        elif [ "$path" = "scaling_governor" ]; then
            cpu_gover=${freq[$mode]}
            set_governor "${policy_num[$counter]}" "$cpu_gover"
        else
            # schedutil调优参数(hispeed_freq/target_loads/hispeed_load)节点不存在时echo_val会静默跳过
            echo_val "${freq[$mode]}" "$policys_path/policy${policy_num[$counter]}/$path"
        fi
    done
}

set_speed() {
    log "set_speed: mode=$mode"
    for counter in "${counters[@]}"
    do
        path=scaling_min_freq
        parse_config "${min_freqs[$counter]}"

        path=scaling_max_freq
        parse_config "${max_freqs[$counter]}"

        path=scaling_governor
        parse_config "${cpu_govers[$counter]}"

        path="$cpu_gover/hispeed_freq"
        parse_config "${hispeed_freqs[$counter]}"

        path="$cpu_gover/target_loads"
        parse_config "${target_loads[$counter]}"

        path="$cpu_gover/hispeed_load"
        parse_config "${hispeed_loads[$counter]}"
    done
}

set_cpu() {
    counter=0
    for tmp in "${cpu_sets[@]}"
    do
        eval "$tmp"
        echo_val "${group[$mode]}" "/dev/cpuset/${cpu_groups[$counter]}/cpus"
        log "set_cpu: ${cpu_groups[$counter]} = ${group[$mode]}"
        counter=$((counter + 1))
    done
}