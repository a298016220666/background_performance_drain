#!/system/bin/sh
MODDIR=$(realpath "${0%/*}/../")
BASEDIR="$(dirname "$(readlink -f "$0")")"
source "$BASEDIR/gen_json.sh" "$1"
echo "$json" > /data/powercfg.json
cp -af "$BASEDIR/powercfg.sh" /data/powercfg.sh

# 修复: 用标记锚点替代硬编码第3行注入, 先删旧注入行再插入
# 避免覆盖安装/更新时重复插入导致每次切换执行多次power_switch.sh
sed -i '/# background_performance_drain_inject/d' /data/powercfg.sh
# 修复: 去掉后台执行&, 改为同步执行, 让外部管理器能确认设置完成
sed -i "1a\sh \"$MODDIR/power_switch.sh\" \"\$1\" # background_performance_drain_inject" /data/powercfg.sh
chmod 755 /data/powercfg.sh