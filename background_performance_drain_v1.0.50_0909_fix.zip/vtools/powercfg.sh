#!/system/bin/sh
# powercfg.sh 入口模板, 由 init_vtools.sh 在第1行后注入 power_switch.sh 调用