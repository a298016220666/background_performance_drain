#!/system/bin/sh
MODDIR=${0%/*}
# 修复: 初始化mode为balance而非空文件, 避免首次调用时空匹配导致直接exit跳过
echo "balance" > "$MODDIR/mode"
sh "$MODDIR/vtools/init_vtools.sh" "$(realpath "$MODDIR/module.prop")"