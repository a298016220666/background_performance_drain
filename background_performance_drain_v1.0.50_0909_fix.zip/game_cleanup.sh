#!/system/bin/sh
# game_cleanup.sh v1.0.48 —— 游戏前一键清理后台抢核进程(配合balance档降功耗)
# 用法: sh /data/adb/modules/background_performance_drain/game_cleanup.sh [--proot] [--wetype]
#   --proot  额外杀掉 proot(Ubuntu/Operit环境, 平时要用慎用, 游戏时必杀)
#   --wetype 额外停掉微信输入法(游戏不用输入法时可杀)
LOG_FILE=/data/local/tmp/background_performance_drain.log
log(){ echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE" 2>/dev/null; }
load(){ cat /proc/loadavg 2>/dev/null | awk '{print $1"/"$2"/"$3}'; }
echo "== 游戏前后台清理 =="
echo "清理前负载: $(load)"
# 1. QQ 全家桶(实测22%CPU+MSF 99%CPU, 抢核头号)
am force-stop com.tencent.mobileqq 2>/dev/null && echo "已停: QQ 主程序"
for p in $(pgrep -f 'com.tencent.mobileqq'); do kill $p 2>/dev/null; done
# 2. proot(可选)
if [ "$1" = "--proot" ] || [ "$2" = "--proot" ]; then
    n=$(pgrep -f 'proot' | wc -l)
    pkill -f 'proot' 2>/dev/null
    [ "$n" -gt 0 ] && echo "已停: proot Ubuntu 环境($n 个进程)"
fi
# 3. 微信输入法(可选)
if [ "$1" = "--wetype" ] || [ "$2" = "--wetype" ]; then
    am force-stop com.tencent.wetype 2>/dev/null && echo "已停: 微信输入法"
fi
sleep 1
echo "清理后负载: $(load)"
log "game_cleanup: done, load before/after=$(cat /proc/loadavg)"
echo "完成。建议切balance档: echo balance > /data/adb/modules/background_performance_drain/mode 后调 power_switch.sh balance"