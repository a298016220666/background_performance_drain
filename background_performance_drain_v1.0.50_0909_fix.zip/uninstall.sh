#!/system/bin/sh
{
	until [ -d /data ]; do
		sleep 1
	done
	rm -f /data/powercfg.json
	rm -f /data/powercfg.sh
	rm -f /data/local/tmp/background_performance_drain.log
} & # do not block boot