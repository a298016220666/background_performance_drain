#!/system/bin/sh
# MT6989 v1.0.49 校准版v9: sched_*档位上下文+performance外挂优化+game_monitor(仅游戏Fast基座/rate_limit跟手/taskset绑核)+防覆盖守护
# 实测: 无畏契约720x1600@120 平均119.5fps/5.58W/GPU仅200-300M/DDR乱跳3000-8500
policy_num=(0 4 7)
counters=(0 1 2)
min_freqs=(
    "freq=(300000 300000 300000 300000)"
    "freq=(700000 700000 700000 700000)"
    "freq=(700000 700000 700000 700000)"
)
max_freqs=(
    "freq=(1600000 1600000 2000000 2000000)"
    "freq=(1200000 1600000 1700000 2850000)"
    "freq=(1200000 1600000 1700000 3250000)"
)
cpu_govers=(
    "freq=(schedutil schedutil schedutil schedutil)"
    "freq=(schedutil schedutil schedutil schedutil)"
    "freq=(schedutil schedutil schedutil schedutil)"
)
hispeed_freqs=(
    "freq=(1600000 1600000 2000000 2000000)"
    "freq=(1200000 1600000 1700000 2850000)"
    "freq=(1200000 1600000 1700000 3250000)"
)
target_loads=(
    "freq=(75 70 55 48)"
    "freq=(90 90 82 72)"
    "freq=(92 92 85 75)"
)
hispeed_loads=(
    "freq=(70 60 50 42)"
    "freq=(95 95 85 75)"
    "freq=(97 97 90 80)"
)
cpu_groups=(background system-background foreground top-app)
cpu_sets=(
    "group=(0-3 0-3 0-3 0-3)"
    "group=(0-3 0-3 0-3 0-3)"
    "group=(0-7 0-3 0-7 0-7)"
    "group=(0-7 0-7 0-7 0-7)"
)

# ============ GPU (Immortalis-G720, 260~1300MHz) ============
# 实测: 120帧最低画质GPU只要200-300M就能稳119.5fps, 上限压很低仍不掉帧
set_gpu() {
    local gpu_min=$1 gpu_max=$2
    local gpu_path="/sys/class/devfreq/13000000.mali"
    [ -e "$gpu_path/min_freq" ] && chmod 666 "$gpu_path/min_freq" 2>/dev/null && echo "$gpu_min" > "$gpu_path/min_freq" 2>/dev/null
    [ -e "$gpu_path/max_freq" ] && chmod 666 "$gpu_path/max_freq" 2>/dev/null && echo "$gpu_max" > "$gpu_path/max_freq" 2>/dev/null
    log "set_gpu: min=$gpu_min max=$gpu_max"
}

# ============ MIGT ============
disable_migt_freq_control() {
    local migt_path="/sys/module/migt/parameters"
    [ -e "$migt_path/flw_freq_enable" ] && chmod 666 "$migt_path/flw_freq_enable" 2>/dev/null && echo "0" > "$migt_path/flw_freq_enable" 2>/dev/null
    [ -e "$migt_path/glk_disable" ] && chmod 666 "$migt_path/glk_disable" 2>/dev/null && echo "1" > "$migt_path/glk_disable" 2>/dev/null
    if [ -e "$migt_path/migt_ceiling_freq" ]; then
        chmod 666 "$migt_path/migt_ceiling_freq" 2>/dev/null
        echo "0:2000 1:2000 2:2000 3:2000 4:2850 5:2850 6:2850 7:3250" > "$migt_path/migt_ceiling_freq" 2>/dev/null
    fi
    log "migt: disabled freq control, ceiling aligned"
}

# ============ 防覆盖守护 guard (v1.0.47 新增) ============
# 问题: scene/系统调度器周期性覆盖sysfs, 一次性写入守不住(实测DDR冲8500M/大核高频)
# 方案: 3s轮询, 仅当偏离目标时才写入(降低写sysfs频率, 省电); 温控throttled时跳过CPU恢复
GUARD_STATE="$MODDIR/guard_state"
GUARD_TEMPSTATE="$MODDIR/temp_state"
start_guard() {
    local mode_guard=$1
    kill_guard
    echo "running" > "$GUARD_STATE"
    local cpu_max0 cpu_max4 cpu_max7 gpu_max dram_target
    case "$mode_guard" in
        balance|1)
            cpu_max0=1600000; cpu_max4=1600000; cpu_max7=1600000
            gpu_min=150000000; gpu_max=260000000
            dram_target=4212000000
            ;;
        powersave|standby|0)
            cpu_max0=1600000; cpu_max4=1200000; cpu_max7=1200000
            gpu_min=150000000; gpu_max=300000000
            dram_target=5460000000
            ;;
        performance|2)
            cpu_max0=2000000; cpu_max4=1700000; cpu_max7=1700000
            gpu_min=260000000; gpu_max=650000000
            dram_target=5460000000
            ;;
        fast|init|pedestal|3)
            cpu_max0=2000000; cpu_max4=2850000; cpu_max7=3250000
            gpu_min=400000000; gpu_max=1100000000
            dram_target=6800000000
            ;;
        *) kill_guard; return ;;
    esac
    (
        while [ "$(cat "$GUARD_STATE" 2>/dev/null)" = "running" ]; do
            local tstate=$(cat "$GUARD_TEMPSTATE" 2>/dev/null)
            # v1.0.49: game_monitor 激活时让路——Fast基座/rate_limit/绑核由 game_monitor 全权管理, guard 不再覆盖
            if [ "$(cat "$MODDIR/game_state" 2>/dev/null)" = "gaming" ]; then
                sleep 3
                continue
            fi
            if [ "$tstate" != "throttled" ]; then
                # CPU: 仅偏离时写回(温控降频时不干扰)
                [ "$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null)" != "$cpu_max0" ] && echo "$cpu_max0" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
                [ "$(cat /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null)" != "$cpu_max4" ] && echo "$cpu_max4" > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
                [ "$(cat /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null)" != "$cpu_max7" ] && echo "$cpu_max7" > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null
            fi
            # GPU: min/max
            [ "$(cat /sys/class/devfreq/13000000.mali/max_freq 2>/dev/null)" != "$gpu_max" ] && echo "$gpu_max" > /sys/class/devfreq/13000000.mali/max_freq 2>/dev/null
            sleep 3
        done
    ) &
    echo $! > "$MODDIR/guard.pid"
    log "guard: started mode=$mode_guard pid=$(cat $MODDIR/guard.pid 2>/dev/null) cpu=($cpu_max0/$cpu_max4/$cpu_max7) gpu=$gpu_max dram=$dram_target"
}
kill_guard() {
    [ -f "$MODDIR/guard.pid" ] && kill $(cat "$MODDIR/guard.pid") 2>/dev/null
    rm -f "$MODDIR/guard.pid"
    echo "stopped" > "$GUARD_STATE" 2>/dev/null
}

# ============ sched_* 档位上下文 (v1.0.48 新增) ============
# 原则: 进 performance 写入优化, 切回 balance/powersave 立即恢复内核默认
# 三档互不污染, balance/powersave 零增量(调度表现与v1.0.47完全一致)
# 注: sched_autogroup_enabled 本机不存在, 写入自动跳过, 无影响
sched_default() {
    # child_runs_first 默认0, rt_runtime 默认950000
    [ -e /proc/sys/kernel/sched_child_runs_first ] && echo 0 > /proc/sys/kernel/sched_child_runs_first 2>/dev/null
    [ -e /proc/sys/kernel/sched_rt_runtime_us ] && echo 950000 > /proc/sys/kernel/sched_rt_runtime_us 2>/dev/null
    # GPU boost 关
    [ -e /sys/module/ged/parameters/boost_gpu_enable ] && echo 0 > /sys/module/ged/parameters/boost_gpu_enable 2>/dev/null
    log "sched_ctx: restored kernel defaults (child=0 rt=950000 gpu_boost=0)"
}
sched_perf() {
    # 外挂调优: 子线程优先跑(外挂逻辑响应快), RT不限流(关键线程不饿死), GPU按需boost
    [ -e /proc/sys/kernel/sched_child_runs_first ] && echo 1 > /proc/sys/kernel/sched_child_runs_first 2>/dev/null
    [ -e /proc/sys/kernel/sched_rt_runtime_us ] && echo -1 > /proc/sys/kernel/sched_rt_runtime_us 2>/dev/null
    [ -e /sys/module/ged/parameters/boost_gpu_enable ] && echo 1 > /sys/module/ged/parameters/boost_gpu_enable 2>/dev/null
    log "sched_ctx: performance (child=1 rt=-1 gpu_boost=1)"
}

# ============ 各档位(v1.0.48 实测校准) ============
# balance: sched_*恢复内核默认(零增量) + A720 1.6G主力+X4 1.6G兜底+rl=5ms+GPU 260M+DDR锁4.21G+guard守护+清后台
balance_func()     { sched_default; disable_migt_freq_control; force_dram 7; set_gpu 150000000 260000000; for p in 0 4 7; do echo 5000 > /sys/devices/system/cpu/cpufreq/policy$p/schedutil/rate_limit_us 2>/dev/null; done; start_guard balance; log "BALANCE(v1.0.48): sched默认 A720 1.6G稳帧 X4 1.6G兜底 DDR锁4.21G GPU260M guard守护 配合game_cleanup清后台"; }
powersave_func()   { sched_default; disable_migt_freq_control; force_dram 6; set_gpu 150000000 300000000; for p in 0 4 7; do echo 5000 > /sys/devices/system/cpu/cpufreq/policy$p/schedutil/rate_limit_us 2>/dev/null; done; start_guard powersave; log "POWERSAVE(v1.0.48日常省电): sched默认 A720 1.6G X4 1.2G兜底 GPU300M DDR 5.46G guard守护"; }
performance_func() { sched_perf; disable_migt_freq_control; force_dram 6; set_gpu 260000000 650000000; start_guard performance; log "PERFORMANCE(v1.0.48外挂优化): sched外挂调优 X4 1.7G GPU 260-650M+boost DDR 5.46G guard守护"; }
fast_func()        { sched_default; disable_migt_freq_control; force_dram 0; set_gpu 400000000 1100000000; start_guard fast; log "FAST(v1.0.48): sched默认 全核满频 GPU顶 guard守护"; }

# ============ DVFSRC 硬件强制 OPP (v1.0.47 突破!) ============
# 背景: devfreq只锁软件目标, 游戏吃带宽时DVFSRC仲裁把DDR顶到6370/8528(实测devfreq锁5460无效)
# 突破: /sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp 强制OPP档位, 绕过仲裁直接锁DDR
# 实测映射(本机天玑9300+):
#   force=0  -> 自动(8528顶)   force=4  -> DDR 6370
#   force=5  -> DDR 5460(730mV) force=6  -> DDR 5460(630mV, 更省)
#   force=7  -> DDR 4212        force=8  -> DDR 4212
#   force=10 -> DDR 3094        force=12 -> DDR 3094
#   force=15 -> DDR 2067        force=19 -> DDR 1540(猜测)
# force=6 实测: 打dd内存带宽都不动, 15秒锁死 -> 这就是硬件锁
DVFSRC_FORCE=/sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp
force_dram() {
    local force_opp=$1
    [ -e "$DVFSRC_FORCE" ] || { log "force_dram: $DVFSRC_FORCE 不存在!"; return 1; }
    chmod 666 "$DVFSRC_FORCE" 2>/dev/null
    echo -n "$force_opp" > "$DVFSRC_FORCE" 2>/dev/null
    log "force_dram: force_opp=$force_opp (DDR硬锁)"
}