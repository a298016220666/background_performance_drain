#!/system/bin/sh
# game_monitor.sh v1.0.49 —— 仅游戏触发: Fast基座 + C(rate_limit跟手) + E(taskset绑核) + 帧率自适应
# 触发: mode=performance 且 前台应用在白名单(games.list)
# 退出: 连续2次(1s)检测非游戏后恢复; 切档立即退出并恢复
# 隔离: balance/powersave 完全不碰, 仅 performance 档下由本守护激活
MODDIR=/data/adb/modules/background_performance_drain
GAMES_LIST="$MODDIR/games.list"
CHEAT_PATTERN="Fuzz_Cheat"
LOG_FILE="/data/local/tmp/background_performance_drain.log"
GM_STATE="$MODDIR/game_state"
RATE_DEFAULT=5000

log() { echo "[$(date '+%m-%d %H:%M:%S')] game_monitor: $*" >> "$LOG_FILE" 2>/dev/null; }

# ---------- 前台应用包名 ----------
get_fg_pkg() {
    dumpsys window 2>/dev/null \
        | grep -o 'mCurrentFocus=Window{[^}]*}' \
        | head -1 | sed 's/.* u0 \([^/]*\)\/.*/\1/'
}

is_in_list() {
    local pkg="$1" line
    [ -z "$pkg" ] && return 1
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        case "$line" in \#*) continue;; esac
        [ "$line" = "$pkg" ] && return 0
    done < "$GAMES_LIST"
    return 1
}

# ---------- E方案: taskset 绑核 (无UClamp, 用taskset隔离) ----------
# cpu0-3=A720中核(2.0G)  cpu4-5=X4(2.85G)  cpu6-7=X4超(3.4G)
# 外挂脚本 -> 中核 cpu0-3 (0x0F); 游戏线程 -> 大核 cpu4-7 (0xF0) 互不抢资源
GAME_MASK=0xF0
CHEAT_MASK=0x0F

bind_cheat() {
    local pid
    for pid in $(pgrep -f "$CHEAT_PATTERN" 2>/dev/null); do
        [ "$(taskset -p "$pid" 2>/dev/null | grep -o '0x0f' )" ] && continue
        taskset -p "$CHEAT_MASK" "$pid" 2>/dev/null
        log "bind_cheat: pid=$pid -> mask=$CHEAT_MASK (中核隔离)"
    done
}

unbind_cheat() {
    local pid
    for pid in $(pgrep -f "$CHEAT_PATTERN" 2>/dev/null); do
        taskset -p 0xFF "$pid" 2>/dev/null
        log "unbind_cheat: pid=$pid -> mask=0xFF (恢复全核)"
    done
}

# ---------- C方案: rate_limit 跟手 (帧率自适应) ----------
# 默认5000(当前档位值) -> 进游戏按帧率目标降延迟跟手; 温控>82°C 兜底回5000
# 仅在值变化时写sysfs, 避免每轮写入增加唤醒
CUR_RATE=""
set_rate_limit() {
    local val=$1
    [ "$val" = "$CUR_RATE" ] && return 0
    for p in 0 4 7; do
        [ -e "/sys/devices/system/cpu/cpufreq/policy$p/schedutil/rate_limit_us" ] \
            && echo "$val" > "/sys/devices/system/cpu/cpufreq/policy$p/schedutil/rate_limit_us" 2>/dev/null
    done
    CUR_RATE="$val"
    log "set_rate_limit: $val us (跟手=C 方案)"
}

restore_rate_limit() { set_rate_limit "$RATE_DEFAULT"; }

# 温控感知: >82°C 回5000让位温控降频, <=82°C 保持跟手
update_rate_by_temp() {
    local tstate temp
    tstate=$(cat "$MODDIR/temp_state" 2>/dev/null)
    temp=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | cut -d' ' -f1)
    if [ "$tstate" = "throttled" ] || { [ -n "$temp" ] && [ "$temp" -gt 82000 ]; }; then
        set_rate_limit "$RATE_DEFAULT"
    else
        set_rate_limit 1000
    fi
}

# ---------- Fast基座: performance 之上叠 Fast 频率上限 (仅游戏内) ----------
apply_fast_base() {
    # 提高大核上限到 fast 级: cpu4=2.85G cpu6-7=3.4G, 中核保持2.0G
    echo 2850000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
    echo 3400000 > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null
    echo 2000000 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
    # GPU 提速(performance 650M -> fast 1100M)
    echo 1100000000 > /sys/class/devfreq/13000000.mali/max_freq 2>/dev/null
    # DDR 由 force6(5.46G) 提至 force0(自动/顶8528) 让位游戏带宽
    chmod 666 /sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp 2>/dev/null
    echo 0 > /sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp 2>/dev/null
    log "apply_fast_base: cpu(2.0/2.85/3.4) GPU1100M DDR auto(Fast基座)"
}

restore_fast_base() {
    # 恢复 performance 档原值
    echo 2000000 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 2>/dev/null
    echo 1700000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_max_freq 2>/dev/null
    echo 1700000 > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null
    echo 650000000 > /sys/class/devfreq/13000000.mali/max_freq 2>/dev/null
    chmod 666 /sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp 2>/dev/null
    echo 6 > /sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp 2>/dev/null
    log "restore_fast_base: 回 performance 原值(cpu2.0/1.7/1.7 GPU650M DDR force6)"
}

# ---------- 状态机 ----------
# IDLE -> GAMING (mode=performance 且前台白名单命中)
# GAMING: 持续守护; 连续2次非游戏 -> 恢复回 IDLE
STATE="idle"
MISS=0
CUR_RATE="$RATE_DEFAULT"

enter_game() {
    STATE="gaming"
    MISS=0
    echo "gaming" > "$GM_STATE" 2>/dev/null
    apply_fast_base
    set_rate_limit 1000          # C方案: 跟手(帧率目标>=100)
    bind_cheat                    # E方案: 外挂绑中核
    log "ENTER_GAME: Fast基座+rate1000+cheat绑核(0x0F)"
}

exit_game() {
    restore_rate_limit
    restore_fast_base
    unbind_cheat
    echo "idle" > "$GM_STATE" 2>/dev/null
    log "EXIT_GAME: rate回$RATE_DEFAULT, Fast基座回退, cheat解绑"
}

while true; do
    # 切档非performance: 立即退出并恢复
    curr_mode=$(cat "$MODDIR/mode" 2>/dev/null)
    if [ "$curr_mode" != "performance" ]; then
        [ "$STATE" = "gaming" ] && { exit_game; STATE="idle"; }
        echo "idle" > "$GM_STATE" 2>/dev/null
        sleep 1
        continue
    fi

    fg=$(get_fg_pkg)
    if is_in_list "$fg"; then
        # 游戏内: 触发/续期
        if [ "$STATE" != "gaming" ]; then
            enter_game
        else
            MISS=0
            # C方案帧率自适应微调: 温控感知跟手
            update_rate_by_temp
            bind_cheat
        fi
    else
        # 非游戏: 连续2次(1s)才退出, 防切屏闪烁
        if [ "$STATE" = "gaming" ]; then
            MISS=$((MISS + 1))
            if [ "$MISS" -ge 2 ]; then
                exit_game
                STATE="idle"
            fi
        fi
    fi
    sleep 0.5
done