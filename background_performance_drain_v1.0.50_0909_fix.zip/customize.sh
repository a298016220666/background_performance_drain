#!/system/bin/sh
ui_print '这是一个设计初衷只为了蹭scene的调度功能所写的假调度，几乎保留了所有官调的内容，又可以蹭scene的功能[核心分配、旁路充电]。'
ui_print '虽然是假调度，但是含有调度基本的频率切换，CPUset、情景模式功能。'
ui_print '必须由scene或perapp-rs等管理器接管，否则无法生效。'
ui_print '如果你想适配你的处理器，请在configs文件夹中添加名称是[getprop ro.soc.model]的结果的配置文件。'

# 修复: 多属性检测soc_model, 增加ro.board.platform和ro.hardware作为备选, 避免空值
soc_model=$(getprop ro.soc.model)
[ -z "$soc_model" ] && soc_model=$(getprop ro.board.platform)
[ -z "$soc_model" ] && soc_model=$(getprop ro.hardware)

ui_print "处理器的型号为：$soc_model"

if [ -z "$soc_model" ] || [ ! -f "$MODPATH/configs/${soc_model}.sh" ]; then
    ui_print "你的处理器不受支持！(soc_model=$soc_model)"
    ui_print "可手动将配置文件复制为 configs/${soc_model}.sh 后重试"
    abort
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644

# 修复: 用占位符替换替代sed行号注入, 避免覆盖安装时重复插入多行
# power_switch.sh中预写了 soc_model= 占位行
sed -i "s/^soc_model=.*/soc_model=$soc_model/" "$MODPATH/power_switch.sh"

# 修复: 安装时不调用init_vtools, 留给service.sh在开机时执行
# (安装时/data可能未完全就绪, 且模块路径尚未最终确定)